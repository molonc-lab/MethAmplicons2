"""
MethAmplicons: A tool for plotting targeted bisulfite sequencing.
"""

__version__ = "0.1"